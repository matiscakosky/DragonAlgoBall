package modelo.excepciones;

public class PosicionInvalida extends RuntimeException {private static final long serialVersionUID = 7526472295622776147L;}
