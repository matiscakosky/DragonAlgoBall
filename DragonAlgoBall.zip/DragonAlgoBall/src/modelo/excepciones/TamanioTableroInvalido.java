package modelo.excepciones;

public class TamanioTableroInvalido extends RuntimeException {private static final long serialVersionUID = 7526472295622776147L;}
