package modelo;

public class Consumible extends ObjetoJuego{

}
