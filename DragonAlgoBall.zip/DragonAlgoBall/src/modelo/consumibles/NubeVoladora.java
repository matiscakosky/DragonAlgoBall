package modelo.consumibles;

public class NubeVoladora {

}
