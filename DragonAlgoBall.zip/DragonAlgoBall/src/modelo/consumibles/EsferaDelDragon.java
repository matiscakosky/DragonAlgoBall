package modelo.consumibles;

public class EsferaDelDragon {

}
