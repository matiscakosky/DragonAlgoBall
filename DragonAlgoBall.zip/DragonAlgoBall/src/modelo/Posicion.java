package modelo;

public class Posicion {
	private int coordenadaX;
	private int coordenadaY;
	
	public Posicion(int cordX, int cordY){
		this.coordenadaX = cordX;
		this.coordenadaY = cordY;
}
	public int getCoordenadaX() {
		return coordenadaX;
	}
	public int getCoordenadaY() {
		return coordenadaY;
	}
}
	
